import package 

print("Hasil penjumlahan:", package.tambah(5, 3))
print("Hasil pengurangan:", package.kurang(10, 4))

print(package.greetings.pagi())
print(package.greetings.siang())
print(package.greetings.sore())
print(package.greetings.malam())