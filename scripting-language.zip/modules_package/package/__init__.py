from .greetings import pagi, siang, sore, malam
from .aritmatika import tambah, kurang, kali, bagi
