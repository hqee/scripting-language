def pagi():
    return "Selamat pagi!"

def siang():
    return "Selamat siang!"

def sore():
    return "Selamat sore!"

def malam():
    return "Selamat malam!"
