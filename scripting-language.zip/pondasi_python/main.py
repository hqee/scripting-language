from package2 import operasiBilangan 
from package2 import menyapa

menyapa.malam()
print(operasiBilangan.penjumlahan(2,3))

print(operasiBilangan.pengurangan(2,3))

print(menyapa.pagi())