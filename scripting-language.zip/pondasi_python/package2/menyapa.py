def pagi():
    return "selamat pagi"

def siang():
    print("Selamat siang")

def malam():
    print("selamat malam")