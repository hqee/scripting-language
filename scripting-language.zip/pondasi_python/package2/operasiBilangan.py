def penjumlahan(a,b):
    return a+b

def pengurangan(a,b):
    return a - b